<?php

/*
	Arquivo principal do curso

	Esse 'include' importa o arquivo de configuração das credenciais:
*/
	include('config/config.php');

/*
	Executa as credenciais na API do Zabbix
*/
	$auth = execLogin(USER,PASSWORD);

/*
	Verifica se o login foi realizado com sucesso
*/
	if($auth){

		/*
			Importa o arquivo de ação desejado no diretório examples:
		*/
			include('examples/history/history.get/ex-01.php');

	} else{

		echo 'Login Errado';

	}

?>


