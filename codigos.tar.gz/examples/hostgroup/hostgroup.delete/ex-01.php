<?php

/*
	Deleta 2 Grupos de Hosts de uma só vez, informando os IDs dos mesmos.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/hostgroup/delete
*/

	$query = array('10','11'); /* IDs dos Hosts a serem deletados */

	$output = execJSON($query,'hostgroup.delete',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Grupo de Hosts deletado: </strong>" . $value . "<br />";
			
		}

    }

?>