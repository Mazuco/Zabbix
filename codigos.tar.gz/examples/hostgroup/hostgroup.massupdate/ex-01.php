<?php

/*
	Substitui todos os Hosts em um Grupo de Hosts.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/hostgroup/massupdate
*/

	
	$query = array(
					'groups' 	=> 	array(
											array(	
													'groupid' => '14',
											)
									), 		
					'hosts' 	=> 	array(
											array(	
													'hostid' => '10142',
											)
									)		
            );

	$output = execJSON($query,'hostgroup.massupdate',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Grupo de Hosts alterado: </strong>" . $value . "<br />";

    	}
    
    }

?>