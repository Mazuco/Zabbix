<?php

/*
	Remove 2 Hosts do Grupo de Host desejado.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/hostgroup/massremove
*/

	$query = array(
					'groupids'	=> 	array('13'),
					'hostids' 	=> 	array('10142','10143')
                  );

	$output = execJSON($query,'hostgroup.massremove',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Grupo de Hosts alterado: </strong>" . $value . "<br />";

    	}
    
    }

?>