<?php

/*
	Adiciona 2 novos Hosts a 2 Grupos de Hosts desejados.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/hostgroup/massadd
*/

	$query = array(
					'groups' 			=> 	array('13','14'), 		/* IDs dos Grupos de Hosts */
					'hosts' 			=> 	array('10142','10143')	/* IDs dos Hosts */
                  );

	$output = execJSON($query,'hostgroup.massadd',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Grupo de Hosts alterado: </strong>" . $value . "<br />";

    	}
    
    }

?>