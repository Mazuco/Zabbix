<?php

/*
	Cria um novo Grupo de Hosts.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/hostgroup/create
*/

	$query = array(
					'name' => 'Novo Curso de Zabbix',
	              );

	$output = execJSON($query,'hostgroup.create',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Grupo de Hosts criado: </strong>" . $value . "<br />";

    	}
    
    }


?>