<?php

/*
	Lista informações dos Grupos de Hosts cadastrados.

	Parametro 'extend' significa que é para exibir todas as informações (sem filtro).

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/hostgroup/get
*/

	$query = array(
					'output' => 'extend',
	              );

	$output = execJSON($query,'hostgroup.get',$auth);

	foreach($output as $dados){

		echo "$dados->groupid - $dados->name <br />";

	}


?>