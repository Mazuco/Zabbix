<?php

/*
	Verifica se é possível a leitura das informações dos Grupos de Hosts desejados.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/hostgroup/isreadable
*/

	$query = array('13','14');

	$output = execJSON($query,'hostgroup.isreadable',$auth);

	echo $output; /* 0 = false, 1 = true */

?>