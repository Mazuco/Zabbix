<?php

/*
	Renomea um Grupo de Hosts.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/hostgroup/update
*/

	$query = array(
					'groupid' 			=> '13', 					/* ID do Grupo de Hosts desejado */
					'name'	 			=> 'Curso de Zabbix API' 	/* Novo nome do Grupo de Hosts */
                  );

	$output = execJSON($query,'hostgroup.update',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Grupo de Hosts alterado: </strong>" . $value . "<br />";

    	}
    
    }

?>