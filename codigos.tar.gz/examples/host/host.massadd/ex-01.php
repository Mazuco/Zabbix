<?php

/*
	/host/host.massadd/ex-01.php

	Adiciona 2 novos Macros para 2 Hosts já criados anteriormente.

	Documentação: https://www.zabbix.com/documentation/4.0/manual/api/reference/host/massadd
*/

	$query = array(
			'hosts'    => 	array('10272','10265'),
			'macros'   => 	array(
						array(	'macro' => '{$TESTE1}','value' => 'MACROTESTE1'
						),
						array(	'macro' => '{$TESTE2}','value' => 'MACROTESTE2'
		   )
	        )
            );

	$output = execJSON($query,'host.massadd',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Host alterado: </strong>" . $value . "<br />";

    	}
    
    }

?>

