<?php

/*
	/host.delete/ex-01.php

	Deleta 2 Hosts de uma só vez, informando os IDs dos mesmos.

	Documentação: https://www.zabbix.com/documentation/4.0/manual/api/reference/host/delete
*/

	$query = array('10270'); /* IDs dos Hosts a serem deletados */

	$output = execJSON($query,'host.delete',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Host deletado: </strong>" . $value . "<br />";
			
		}

    }

?>
