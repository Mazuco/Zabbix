<?php

/*
	Lista os "Templates" de cada Host cadastrado.

	Para checar mais informações, é necessário verificar o retorno do JSON.

	Documentação: https://www.zabbix.com/documentation/4.0/manual/api/reference/host/get
*/

	$query = array(
					'output' => 'extend',
					'selectParentTemplates' => array("templateid", "name")
                  );

	$output = execJSON($query,'host.get',$auth);

	foreach($output as $dados){

		echo "<strong> $dados->host </strong> <br />";

		foreach($dados->parentTemplates as $dadosTemplates){

			echo "<i> $dadosTemplates->templateid - $dadosTemplates->name </i> <br />";

		}

		echo "<br />";

    }

?>
