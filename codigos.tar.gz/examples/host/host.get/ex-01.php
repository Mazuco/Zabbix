<?php

/*
	Lista informações dos Hosts cadastrados.

	Para checar todas as informações coletadas, é necessário verificar o retorno do JSON
	Ex.: hostid, host, available.

	Documentação: https://www.zabbix.com/documentation/4.0/manual/api/reference/host/get
*/

	$query = array(
					'output' => 'extend',  # O 'extend' mostra tudo
	              );

	$output = execJSON($query,'host.get',$auth);

	foreach($output as $dados){  # 'foreach' varre o array

		echo "$dados->hostid - $dados->host <br />";

	}


?>
