<?php

/*
	Lista os Grupos de um Host em especifico.

	Substitua: 'filter' => array('host' => array('host_desejado'))

	Documentação: https://www.zabbix.com/documentation/4.0/manual/api/reference/host/get
*/

	$query = array(
					'output' => 'extend',
					'selectGroups' => 'extend',
					'filter' => array('host' => array('Zabbix server'))
                  );

	$output = execJSON($query,'host.get',$auth);

	foreach($output as $dados){

		echo "<strong> $dados->host </strong> <br />";

		foreach($dados->groups as $dadosGroups){

			echo "<i>$dadosGroups->groupid - $dadosGroups->name </i> <br />";

		}

		echo "<br />";

    }

?>







