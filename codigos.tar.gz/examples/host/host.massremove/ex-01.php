<?php

/*
	/host/host.massremove/ex-01.php

	Desassociar e limpar 1 mesmo Template em 1 ou mais Hosts diferentes.

	Documentação: https://www.zabbix.com/documentation/4.0/manual/api/reference/host/massremove
*/

	$query = array(
			'hostids'		=> 	array('10272','10265'),
			'templateids_clear' 	=> 	'10186' /* Template Module ICMP Ping */
                  );

	$output = execJSON($query,'host.massremove',$auth);

	echo "<strong>Alteração feita com sucesso! </strong>";

?>
