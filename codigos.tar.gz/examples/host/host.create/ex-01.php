<?php

/*
	/host/host.create/ex-01.php

	Cria um novo Host chamado "Curso Zabbix API" com uma interface IP, em um Grupo especifico
	linkado a um Template e adicionado os MAC Adressess no Inventário do Host.

	Documentação: https://www.zabbix.com/documentation/4.0/manual/api/reference/host/create
*/

	$query = array(
				'host' 			=> 'Zabbix API PHP',
				'interfaces' 	=> array(	'type' 	=> 1,
								'main' 	=> 1,
								'useip' => 1,
								'ip'	=> '192.168.0.98',
								'dns'	=> '',
								'port'	=> '10050'
										 	),
				 'groups'	=> array(
								'groupid' => '2' /* Linux Servers */
									 		),
				 'templates' 	=> array(
								'templateid' => '10001' /* Template OS Linux */
									 		),
					'invetory_mode' => 0, /* Manual */
					'inventory' 	=> array(
								  'macaddress_a' => '01234',
							          'macaddress_b' => '56789'
											)
                  );

	$output = execJSON($query,'host.create',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Host criado: </strong>" . $value . "<br />";

    	}
    
    }

?>
