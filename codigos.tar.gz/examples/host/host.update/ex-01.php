<?php

/*
	/host.update/ex-01.php

	Ativa/Desativa o monitoramento de um Host específico.

	Documentação: https://www.zabbix.com/documentation/4.0/manual/api/reference/host/update
*/

	$query = array(
					'hostid' 	=> '10270', /* ID do Host desejado */
					'status' 	=> 1 	   /* 0 = Ativo, 1 = Inativo */
                  );

	$output = execJSON($query,'host.update',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Host alterado: </strong>" . $value . "<br />";

    	}

    }

?>
