<?php

/*
	/host/host.massupdate/ex-01.php

	Ativa/Inativa o monitoramento de 2 Hosts já criados.

	Documentação: https://www.zabbix.com/documentation/4.0/manual/api/reference/host/massupdate
*/

	$query = array(
			'hosts'		=> 	array(
						array('hostid' => '10272',
						),
						array(
						'hostid' => '10266',
					 )
					),
			'status' 	=> 	0 /* 0 = Ativo, 1 = Inativo */
                  );

	$output = execJSON($query,'host.massupdate',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Host alterado: </strong>" . $value . "<br />";

    	}
    
    }

?>
