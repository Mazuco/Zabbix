<?php

session_start();

include('config/config.php');

protegeLogin();

$auth = $_SESSION['auth'];

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Área Administrativa | WebApp Zabbix API</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
    
    <div class="container-fluid">
      <div class="col-md-12">
        
        <center>
        	<h2>
        		Área Administrativa do Zabbix
        		<a class="btn btn-default pull-right" href="sair.php">
        			<span class="glyphicon glyphicon-log-out" aria-hidden="true"></span> Sair
        		</a>
        	</h2>
        </center>

        <!-- Importação de Hosts -->
        <div class="well">
        	<h3>Importar os Hosts</h3>
        	<hr>
        	<form method="POST" action="include/importa-hosts.php" enctype="multipart/form-data">			  
    			  <div class="form-group">
    			    <label>Arquivo de importação</label>
    			    <input type="file" id="hosts" name="hosts">
    			    <p class="help-block">Adicione o arquivo em formato .csv para importação.</p>
    			  </div>
    			  <hr>
    			  <button type="submit" class="btn btn-primary">Enviar</button>
    			</form>
        </div>
        <!-- /. Importação de Hosts -->

        <!-- Relatório de Itens não suportados -->
        <div class="well">
        	<h3>Itens não suportados</h3>
        	<hr>
        	<div class="table-responsive">
            <table class="table table-striped table-condensed table-hover">
            	<thead>
              	<tr>
              		<th><center>ID do Host</center></th>
              		<th><center>ID do Item</center></th>
              		<th><center>Nome</center></th>
              		<th><center>Chave</center></th>
              		<th><center>Erro</center></th>
              	</tr>
              </thead>
              <tbody>
            	<?php

            		$query = array(
    					                 'output' 	=> 'extend',
    					                 'filter'	  => array('state' => 1)
    	                  );

    				    $output = execJSON($query,'item.get',$auth);

    				    foreach($output as $dados){

    			    ?>

      						<tr>
      							<td><center><?php echo $dados->hostid; ?></center></td>
      							<td><center><?php echo $dados->itemid; ?></center></td>
      							<td><?php echo $dados->name; ?></td>
      							<td><?php echo $dados->key_; ?></td>
      							<td><?php echo $dados->error; ?></td>
      						</tr>

              <?php

	              }

  	           ?>

        			</tbody>
        		</table>
        	</div>
        </div>
        <!-- /. Relatório de Itens não suportados -->

        <!-- Relatório de Triggers com problemas -->
        <div class="well">
        	<h3>Triggers com problemas</h3>
        	<hr>
        	<div class="table-responsive">
          	<table class="table table-striped table-condensed table-hover">
            	<thead>
              	<tr>
              		<th><center>Host</center></th>
              		<th><center>ID da Trigger</center></th>
              		<th><center>Descrição</center></th>
              		<th><center>Última Alteração</center></th>
              		<th><center>Prioridade</center></th>
              	</tr>
              </thead>
              <tbody>
        	    <?php

        		    $query =  array(
					                       'output'		    => array('triggerid','description','priority','lastchange'),
					                       'selectHosts'	=> array('hostid','host'),
					                       'filter' 		  => array('value' => 1),
					                       'sortfield' 	  => 'priority',
					                       'sortorder' 	  => 'DESC'
	                        );

				        $output = execJSON($query,'trigger.get',$auth);

				        foreach($output as $dados){

  					      $priority = $dados->priority;

        					if($priority == 0){$style = 'background-color:#7499FF;';}
        					if($priority == 1){$style = 'background-color:#FFC859;';}
        					if($priority == 2){$style = 'background-color:#FFA059;';}
        					if($priority == 3){$style = 'background-color:#E97659;';}
        					if($priority == 4){$style = 'background-color:#E45959;';}

  					      $timestamp = $dados->lastchange;
  					      $horario = gmdate("d/m/Y \ H:i:s", $timestamp);

			        ?>

      						<tr>
      							<td><center><?php echo $dados->hosts[0]->host; ?></center></td>
      							<td><center><?php echo $dados->triggerid; ?></center></td>
      							<td><center><?php echo $dados->description; ?></center></td>
      							<td><center><?php echo $horario; ?></center></td>
      							<td style="<?php echo $style; ?>"></td>
      						</tr>

			        <?php

				        }

        	    ?>

        			</tbody>
        		</table>
        	</div>
        </div>
        <!-- /. Relatório de Triggers com problemas -->

        <!-- Desabilitação de Itens não suportados -->
      	<div class="well">
      		<h3>Desabilitar Itens não suportados</h3>
          <hr>
        	<form method="POST" action="include/desabilita-itens.php">			  
			      <button type="submit" class="btn btn-primary">Desabilitar</button>
			    </form>
      	</div>
      	<!-- /. Desabilitação de Itens não suportados -->

      </div>
      <a href="http://vmzsolutions.com.br"><center><img class="img-responsive" src="imgs/bytelivre.png"></center>
    </div>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
