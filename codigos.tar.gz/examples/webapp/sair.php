<?php

session_start();

session_destroy();

$redirecionar = "index.php";

header("Location: $redirecionar");

die();

?>