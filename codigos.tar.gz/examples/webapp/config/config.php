<?php

/*
	Definir as informações de acordo com os dados da sua infraestrutura

	URL: 		Endereço completo da API do Zabbix em seu servidor
*/
	define('URL','http://192.168.0.20/zabbix/api_jsonrpc.php');

/*
	Função para pesquisa do JSON da API do Zabbix
*/
	function execJSON($query,$method,$auth){

	    try{

			$post = array('jsonrpc' => '2.0',

	    		'method' => $method,

	    		'params' => $query,

	    		'auth' => $auth,

	    		'id' => 1

			);

			$data = json_encode($post);

			$curl = exec("which curl");

			$curlStr = "$curl -X POST -H 'Content-Type: application/json' -d '$data' " . URL;

			/* Exibe saida do JSON */
			//echo $curlStr;

			$execCurl = exec($curlStr);

			$curlOutput = json_decode($execCurl);

			return $curlOutput->result;

		}catch (Exception $e){

	      	echo "Exceção: ",  $e->getMessage(), "\n";

	    }

	}

/*
	Função que realiza o login na API do Zabbix
*/
	function execLogin($user,$password){

		try{

			$queryAuth = array(

							'user' => $user,
			                'password' => $password

			            );

			$auth = execJSON($queryAuth,'user.login',null);

			if(strlen($auth) == 32){

				$auth = execJSON($queryAuth,'user.login',null);
				
				session_start();
				$_SESSION['auth'] = $auth;
				$_SESSION['login'] = true;
				
				$redirect = '../area-admin.php';
				header("Location: $redirect");


			}else{

				echo '<script>alert("Usuario ou Senha incorretos."); window.location = "../index.php";</script>';
			
			}

		}catch (Exception $e){

	      	echo "Exceção: ",  $e->getMessage(), "\n";

	    }

	}

/*
	Função que protege a sessão de login
*/
	function protegeLogin(){
		
		$login_ok = $_SESSION['login'];
		
		if($login_ok != true){
    		
    		$redirecionar = "index.php";
    		header("Location: $redirecionar");
		
		}

	}

?>
