<?php

include('../config/config.php');

$usuario = $_POST['usuario'];
$senha = $_POST['senha'];

execLogin($usuario,$senha);

?>