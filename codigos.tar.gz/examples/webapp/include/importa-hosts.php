<?php 

/* Iniciar a sessao */
session_start();

/* Importar o arquivo de configuracao */
include('../config/config.php');

/* Proteger o login */
protegeLogin();

/* Token de autenticacao */
$auth = $_SESSION['auth'];

/* Verifico se o arquivo existe */
if($_FILES['hosts']['name'] != "") {

	/* Pegar o nome do arquivo */
	$nome = $_FILES['hosts']['name'];

	/* Arquivos permitidos */
	$permitidos = array(".csv");

	/* Separando o nome do arquivo da ext. */
	$ext = strtolower(strrchr($nome,"."));

	/* Verifica se o arquivo é do tipo .csv */
	if(in_array($ext,$permitidos)){

		/* Criptografar o nome do arquivo */
		$nome_cript = $_FILES['hosts']['name'] = md5(uniqid(time())).$ext;

		/* Movendo o arquivo da pasta temporaria e passando o arquivo pra pastar /arquivos/ */
		move_uploaded_file($_FILES['hosts']['tmp_name'],"../arquivos/".$_FILES['hosts']['name']);

		/* Crio o path com o nome criptografado */
		$path = "../arquivos/".$nome_cript;

		/* Abrir o arquivo .cvs */
		$objeto = fopen($path,'r');

		/* Com o arquivo aberto, execute */
		while(($dados = fgetcsv($objeto, 1024, ',')) !== FALSE){

			/* Nomeando as colunas do arquivo */
			$host_nome 		= $dados[0];
			$host_ip 		= $dados[1];
			$host_grupo 	= $dados[2];
			$host_template 	= $dados[3];

			/* Cadastro os hosts no Zabbix */
			$query 	= 	array(
							'host' 			=> 	$host_nome,
							'interfaces' 	=> 	array(	'type' 	=> 1,
														'main' 	=> 1,
														'useip' => 1,
														'ip'	=> $host_ip,
														'dns'	=> '',
														'port'	=> '10050'
										 		),
							'groups' 		=> 	array(
														'groupid' => $host_grupo
									 			),
							'templates' 	=> 	array(
														'templateid' => $host_template
									 			)

                  		);

			/* Executa o cadastro dos hosts no Zabbix */
			$output = execJSON($query,'host.create',$auth);

		}

		/* Fecho arquivo .csv */
		fclose($objeto);

		/* Mensagem de sucesso */
		echo '<script>alert("Hosts importados com sucesso!"); window.location = "../area-admin.php";</script>';

	}else{

		/* Mensagem de erro de ext. de arquivo */
		echo '<script>alert("Tipo de arquivo nao suportado. Utilize o formato .csv!"); window.location = "../area-admin.php";</script>';

	}

} else {

	/* Mensagem de erro de upload */
	echo '<script>alert("Erro ao realizar o upload do arquivo!"); window.location = "../area-admin.php";</script>';

}

?>
