<?php

session_start();

include('../config/config.php');

protegeLogin();

$auth = $_SESSION['auth'];

$query = array(
				'output' 	=> 'extend',
				'filter'	=> array('state' => 1),
				'monitored' => 'true'
	    );

$output = execJSON($query,'item.get',$auth);

foreach($output as $dados){

	$query = array(
					'itemid' => "$dados->itemid",
					'status' => 1
			);
	
	$output = execJSON($query,'item.update',$auth);

}

$redirecionar = "../area-admin.php";
header("Location: $redirecionar");


?>