<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>WebApp Zabbix API</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
    
    <div class="container-fluid">
      <div class="col-md-12 well">
        <center><h2>WebApp Zabbix API - PHP</h2></center>
        <form method="POST" action="include/autentica-login.php">
          <div class="form-group">
            <label>Usuário</label>
            <input type="text" class="form-control" id="usuario" name="usuario">
          </div>
          <div class="form-group">
            <label>Senha</label>
            <input type="password" class="form-control" id="senha" name="senha">
          </div>
          <button type="submit" class="btn btn-default">Entrar</button>
        </form>
      </div>
	  <a href="http://vmzsolutions.com.br"><center><img class="img-responsive" src="imgs/bytelivre.png"></center>
    </div>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
