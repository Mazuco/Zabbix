<?php

/*
	Deleta 2 Triggers de uma só vez, informando os IDs dos mesmos.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/trigger/delete

*/

	$query = array('14522'); /* IDs das Triggers a serem deletadas */

	$output = execJSON($query,'trigger.delete',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID da Trigger deletada: </strong>" . $value . "<br />";
			
		}

    }

?>