<?php

/*
	Retorna o ID, nome e severidade de todas as Triggers com status de PROBLEMA ordenado por severidade.
	
	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/trigger/get
*/

	$query = array(
					'output'	=> array('triggerid','description','priority'),
					'filter' 	=> array('value' => 1),
					'sortfield' => 'priority',
					'sortorder' => 'DESC'
	              );

	$output = execJSON($query,'trigger.get',$auth);

	foreach($output as $dados){

		echo "<strong>ID da Trigger:</strong> $dados->triggerid <br />";
		echo "<strong>Descricao:</strong> $dados->description<br />";
		echo "<strong>Severidade:</strong> $dados->priority<br />";
		echo "<hr>";

	}

?>