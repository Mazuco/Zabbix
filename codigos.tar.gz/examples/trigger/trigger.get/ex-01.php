<?php

/*
	Exibe todos os dados e funções usadas na Trigger desejada. 

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/trigger/get
*/

	$query = array(
					'triggerids' 		=> '10016',
					'output'			=> 'extend',
					'selectFunctions' 	=> 'extend'
	              );

	$output = execJSON($query,'trigger.get',$auth);

	foreach($output as $dados){

		echo "<strong>Descricao:</strong> $dados->description <br />";
		echo "<strong>Severidade:</strong> $dados->priority";

	}

?>