<?php

/*
	Cria uma Trigger

	Documentação: https://www.zabbix.com/documentation/4.0/manual/api/reference/trigger/create
*/

	$query = array(
					'description' => 'Pouco espaço em disco em {HOST.NAME}',
					'expression'  => '{Curso Zabbix API:vfs.fs.size[/home/zabbix/, free].last()}<1000',
					'priority'	  => 3
	              );

	$output = execJSON($query,'trigger.create',$auth);

	foreach($output as $dados){

		foreach ($dados as $value) {
			
			echo "<strong>ID da Trigger criada: </strong>" . $value . "<br />";

		}
    
    }

?>
