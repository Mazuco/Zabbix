<?php

/*
	Faz de uma Trigger dependente de outra

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/trigger/adddependencies
*/

	$query = array(
					'triggerid' 			=> '14523',
					'dependsOnTriggerid'  	=> '14525'
	              );

	$output = execJSON($query,'trigger.adddependencies',$auth);

	foreach($output as $dados){

		foreach ($dados as $value) {
			
			echo "<strong>ID da Trigger alterada: </strong>" . $value . "<br />";

		}
    
    }


?>