<?php

/*
	Verifica se é possível a leitura das informações das Triggers desejadas.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/trigger/isreadable
*/

	$query = array('14523');

	$output = execJSON($query,'trigger.isreadable',$auth);

	echo $output; /* 0 = false, 1 = true */

?>