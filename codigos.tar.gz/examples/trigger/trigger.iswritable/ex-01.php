<?php

/*
	Verifica se é possível a escrita das informações das Triggers desejadas.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/trigger/iswritable
*/

	$query = array('14523');

	$output = execJSON($query,'trigger.iswritable',$auth);

	echo $output; /* 0 = false, 1 = true */

?>