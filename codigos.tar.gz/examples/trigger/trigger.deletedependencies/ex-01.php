<?php

/*
	Deleta todas as dependencias de uma Trigger desejada

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/trigger/deletedependencies
*/

	$query = array(
					array('triggerid' => '14523'),
	              );

	$output = execJSON($query,'trigger.deletedependencies',$auth);

	foreach($output as $dados){

		foreach ($dados as $value) {
			
			echo "<strong>ID da Trigger alterada: </strong>" . $value . "<br />";

		}
    
    }


?>