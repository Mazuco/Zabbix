<?php

/*
	Ativa uma Trigger que está como inativa.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/trigger/update
*/

	$query = array(
					'triggerid' 	=> '14523', 	/* ID da Trigger desejada */
					'status'	 	=> 0 			/* 0 = Ativo, 1 = Inativo */
                  );

	$output = execJSON($query,'trigger.update',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID da Trigger alterada: </strong>" . $value . "<br />";

    	}
    
    }

?>