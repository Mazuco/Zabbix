<?php

/*
	Exibe as últimas alertas de uma determinada Ação

	Documentação: https://www.zabbix.com/documentation/4.0/manual/api/reference/alert/get
*/

	$query = array(
					'output' 	=> 'extend',
					'actionids'	=> '3' /* ID da Ação desejada */
	              );

	$output = execJSON($query,'alert.get',$auth);

	foreach($output as $dados){

		echo "<strong>ID da Alerta:</strong> $dados->alertid <br />";
		echo "<strong>Horario:</strong> $dados->clock <br />";
		echo "<strong>Enviado para:</strong> $dados->sendto <br />";
		echo "<strong>Assunto:</strong> $dados->subject <br />";
		echo "<strong>Mensagem:</strong> $dados->message";
		echo "<hr>";

	}

?>
