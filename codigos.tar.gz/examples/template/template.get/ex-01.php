<?php

/*
	Lista todas as informações de Templates especificos.

	Substitua: 'filter' => array('host' => array('template_desejado'))

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/template/get
*/

	$query = array(
					'output' => 'extend',
					'filter' => array('host' => array('Template OS Linux','Template App Zabbix Server'))
                  );

	$output = execJSON($query,'template.get',$auth);

	foreach($output as $dados){

		echo "$dados->templateid - <strong> $dados->host </strong> <br />";

		echo "<br />";

    }

?>