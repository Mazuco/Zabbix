<?php

/*
	Verifica se é possível a escrita das informações dos Templates desejados.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/template/iswritable
*/

	$query = array('10144','10125');

	$output = execJSON($query,'template.iswritable',$auth);

	echo $output; /* 0 = false, 1 = true */

?>