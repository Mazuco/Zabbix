<?php

/*
	Cria um novo Template, adiciona o mesmo em um grupo e linka 2 Hosts neste Template.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/template/create
*/

	$query = array(
					'host' 		=> 'Template Curso de Zabbix API',
					'groups'	=> array(
											'groupid' => '1'	/* ID do grupo Templates */
										), 
					'hosts'		=> array(
											array('hostid' => '10142'),	/* ID do Host vinculado */
											array('hostid' => '10143') 	/* ID do Host vinculado */
										)
	              );

	$output = execJSON($query,'template.create',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Template criado: </strong>" . $value . "<br />";

    	}
    
    }


?>