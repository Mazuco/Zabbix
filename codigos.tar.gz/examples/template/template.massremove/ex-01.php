<?php

/*
	Remove 2 Templates de um Grupo de Hosts desejado.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/template/massremove
*/

	$query = array(
					'templateids'	=> 	array('10144','10125'),
					'groupids' 		=> 	array('13')
                  );

	$output = execJSON($query,'template.massremove',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Template alterado: </strong>" . $value . "<br />";

    	}
    
    }

?>