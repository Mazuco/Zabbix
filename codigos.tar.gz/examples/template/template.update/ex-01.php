<?php

/*
	Renomea um Template.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/template/update
*/

	$query = array(
					'templateid' 	=> '10144', 					 	/* ID do Template desejado */
					'name'	 		=> 'Template Curso Zabbix API' 		/* Novo nome do Template */
                  );

	$output = execJSON($query,'template.update',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Template alterado: </strong>" . $value . "<br />";

    	}
    
    }

?>