<?php

/*
	Deleta 2 Templates de uma só vez, informando os IDs dos mesmos.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/template/delete
*/

	$query = array('10126','10127'); /* IDs dos Templates a serem deletados */

	$output = execJSON($query,'template.delete',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Template deletado: </strong>" . $value . "<br />";
			
		}

    }

?>