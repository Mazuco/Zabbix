<?php

/*
	Adiciona 2 Templates a 1 Grupo de Hosts desejado.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/template/massadd
*/

	$query = array(
					'templates' 		=> 	array(
													array('templateid' => '10125'),
													array('templateid' => '10144'),
												 ), 		
					'groups' 			=> 	array(
													array('groupid' => '13'),
												 )
                  );

	$output = execJSON($query,'template.massadd',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Template alterado: </strong>" . $value . "<br />";

    	}
    
    }

?>