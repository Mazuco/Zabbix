<?php

/*
	Desassociar e limpar um Template dos Templates dados.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/template/massupdate
*/

	
	$query = array(
					'templates' 		=> 	array(
													array('templateid' => '10125'),
													array('templateid' => '10145')
											 	 ), 		
					'templates_clear' 	=> 	array(
													array('templateid' => '10144'),
												 )		
                  );

	$output = execJSON($query,'template.massupdate',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Template alterado: </strong>" . $value . "<br />";

    	}
    
    }

?>