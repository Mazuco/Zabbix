<?php

/*
	Exibe todos os Itens que tenha a palavra "system" ordenado pelo "nome", de um Host desejado 

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/item/get
*/

	$query = array(
					'output' 	=> 'extend',
					'hostids'	=> '10084',
					'search'	=> array('key_' => 'system'),
					'sortfield' => 'name'
	              );

	$output = execJSON($query,'item.get',$auth);

	foreach($output as $dados){

		echo "<strong>$dados->name:</strong> $dados->key_ <br />";

	}

?>