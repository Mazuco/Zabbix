<?php

/*
	Cria um Item tipo "Agent Zabbix númerico" para monitorar o espaço em disco de um Host especifico adicionando duas Aplicações a este Item

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/item/create
*/

	$query = array(
					'name' 			=> 'Espaço livre em $1', /* Nome do Item */
					'key_' 			=> 'vfs.fs.size[/home/zabbix/, free]', /* Chave do Item */
					'hostid' 		=> '10142', /* ID do Host já criado */
					'type' 			=> 0, /* ID da Interface do Item: 0 = Agent Zabbix */
        			'value_type' 	=> 3, /* ID do Tipo de Dados: 3 = Decimal */
        			'interfaceid' 	=> '33', /* ID da Interface (localhost) */
        			'applications'	=> array('874','875'), /* ID das Aplicações já criadas */
        			'delay'			=> '30' /* Intervalo de atulização do Item em segundos */

	              );

	$output = execJSON($query,'item.create',$auth);

	foreach($output as $dados){

		foreach ($dados as $value) {
			
			echo "<strong>ID do Item criado: </strong>" . $value . "<br />";

		}
    
    }


?>