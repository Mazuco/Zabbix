<?php

/*
	Deleta 2 Itens de uma só vez, informando os IDs dos mesmos.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/item/delete

*/

	$query = array('25672','25673'); /* IDs dos Itens a serem deletados */

	$output = execJSON($query,'item.delete',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Item deletado: </strong>" . $value . "<br />";
			
		}

    }

?>