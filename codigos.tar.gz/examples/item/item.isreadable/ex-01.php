<?php

/*
	Verifica se é possível a leitura das informações dos Itens desejados.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/item/isreadable
*/

	$query = array('25675','25674');

	$output = execJSON($query,'item.isreadable',$auth);

	echo $output; /* 0 = false, 1 = true */

?>