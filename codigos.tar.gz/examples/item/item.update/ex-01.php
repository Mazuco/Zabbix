<?php

/*
	Ativa um item que está como inativo.

	Documentação: https://www.zabbix.com/documentation/2.4/manual/api/reference/item/update
*/

	$query = array(
					'itemid' 			=> '25674', 	/* ID do Item desejado */
					'status'	 		=> 0 			/* 0 = Ativo, 1 = Inativo */
                  );

	$output = execJSON($query,'item.update',$auth);

	foreach($output as $dados){

		foreach ($dados as $value){

			echo "<strong>ID do Item alterado: </strong>" . $value . "<br />";

    	}
    
    }

?>