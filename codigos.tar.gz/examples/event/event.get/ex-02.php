<?php

/*
	/event/event.get/ex-02.php

	Exibe todos os eventos ocorridos entre 01/03/2019 (1551398400) e 01/04/2019 (1554076800) em ordem cronológica reversa

	Documentação: 	Documentação: https://www.zabbix.com/documentation/4.0/manual/api/reference/event/get
*/

	$query = array(
					'output' 		=> 'extend',
					'time_from'		=> '1551398400', /* UNIX Time do dia 01/03/2019 */
					'time_till' 	=> '1554076800', /* UNIX Time do dia 01/04/2019 */
					'sortfield' 	=> array('clock','eventid'),
					'sortorder' 	=> 'DESC'
	              );

	$output = execJSON($query,'event.get',$auth);

	foreach($output as $dados){

		/* Converte o UNIX Time */
		$timestamp = $dados->clock;
		$horario = gmdate("d-m-Y \ H:i:s", $timestamp);

		echo "<strong>ID do Evento:</strong> $dados->eventid <br />";
		echo "<strong>Data e Horário:</strong> $horario <br />";
		echo "<strong>Foi reconhecido?:</strong> $dados->acknowledged"; /* 0 = Não, 1 = Sim */
		echo "<hr>";

	}

?>
