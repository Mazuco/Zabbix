<?php

/*
	/event/event.get/ex-01.php

	Exibe os últimos eventos de uma determinada Trigger

	Documentação: https://www.zabbix.com/documentation/4.0/manual/api/reference/event/get
*/

	$query = array(
					'output' 				=> 'extend',
					'select_acknowledges'	=> 'extend',
					'objectids' 			=> '16012',
					'sortfield' 			=> array('clock','eventid'),
					'sortorder' 			=> 'DESC'
	              );

	$output = execJSON($query,'event.get',$auth);

	foreach($output as $dados){

		echo "<strong>ID do Evento:</strong> $dados->eventid <br />";
		echo "<strong>Horário:</strong> $dados->clock <br />";
		echo "<strong>Reconhecido:</strong> $dados->acknowledged"; /* 0 = Não, 1 = Sim */
		echo "<hr>";

	}

?>
