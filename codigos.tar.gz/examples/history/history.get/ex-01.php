<?php

/*
	/history/history.get/ex-01.php

	Exibe os 10 últimos valores recebidos de um Item Numérico (fracionário)

	Documentação: https://www.zabbix.com/documentation/4.0/manual/api/reference/history/get
*/

	$query = array(
					'output' 	=> 'extend',
					'history'	=> 0,
					'itemids' 	=> '28720',
					'sortfield' => 'clock',
					'sortorder' => 'DESC',
					'limit' 	=> 10
	              );

	$output = execJSON($query,'history.get',$auth);

	foreach($output as $dados){

		echo "<strong>ID do Item:</strong> $dados->itemid <br />";
		echo "<strong>Horário:</strong> $dados->clock <br />";
		echo "<strong>Valor:</strong> $dados->value";
		echo "<hr>";

	}

?>
