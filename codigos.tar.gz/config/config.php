<?php

/*
	Definir as informações de acordo com os dados da sua configuração

	URL: 		Endereço completo da API do Zabbix em seu servidor
	USER: 		Usuário de acesso a interface web do Zabbix
	PASSWORD:	Senha do usuário de acesso a interface web do Zabbix
	Documentação:   https://www.zabbix.com/documentation/4.0/manual/api

*/

	define('URL','http://192.168.0.20/zabbix/api_jsonrpc.php');
	define('USER','Admin');
	define('PASSWORD','zabbix');

/*
	Função para pesquisa do JSON da API do Zabbix
*/
	function execJSON($query,$method,$auth){

	    try{

			$post = array('jsonrpc' => '2.0',

	    		'method' => $method,

	    		'params' => $query,

	    		'auth' => $auth,

	    		'id' => 1

			);

			$data = json_encode($post);

			$curl = exec("which curl");

			$curlStr = "$curl -X POST -H 'Content-Type: application/json' -d '$data' " . URL;

			/* Exibe saida do JSON */
			//echo $curlStr;

			$execCurl = exec($curlStr);

			$curlOutput = json_decode($execCurl);

			return $curlOutput->result;

		} catch (Exception $e){

	      	echo "Exceção: ",  $e->getMessage(), "\n";

	    }

	}

/*
	Função que realiza o login na API do Zabbix
*/
	function execLogin($user,$password){

		try{

			$queryAuth = array(

							'user' => $user,
			                'password' => $password

			            );

			$auth = execJSON($queryAuth,'user.login',null);

			if(strlen($auth) == 32){

				return $auth = execJSON($queryAuth,'user.login',null);

			}else{

				return false;
			
			}

		}catch (Exception $e){

	      	echo "Exceção: ",  $e->getMessage(), "\n";

	    }

	}

?>
